<div class="container">
    <div class="row mt-3">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Form Tambah Data Peminjaman Buku
                </div>
                <div class="card-body">
                    <form action="" method="POST">
                        <div class="form-group">
                            <label for="nama_lengkap">Nama</label>
                            <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap">
                            <small class="form-text text-danger"><?= form_error('nama_lengkap'); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="nis">NIS</label>
                            <input type="text" class="form-control" id="nis" name="nis">
                            <small class="form-text text-danger"><?= form_error('nis'); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="kelas">Kelas</label>
                            <input type="text" class="form-control" id="kelas" name="kelas">
                            <small class="form-text text-danger"><?= form_error('kelas'); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="judul_buku">Judul Buku</label>
                            <input type="text" class="form-control" id="judul_buku" name="judul_buku">
                            <small class="form-text text-danger"><?= form_error('judul_buku'); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="tgl_pinjam">Tanggal Pinjam</label>
                            <input type="date" class="form-control" id="tgl_pinjam" name="tgl_pinjam">
                            <small class="form-text text-danger"><?= form_error('tgl_pinjam'); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="tgl_kembali">Tanggal Kembali</label>
                            <input type="date" class="form-control" id="tgl_kembali" name="tgl_kembali">
                            <small class="form-text text-danger"><?= form_error('tgl_kembali'); ?></small>
                        </div>
                        <button type="submit" name="tambah" class="btn btn-primary mt-3">Tambah Data</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>