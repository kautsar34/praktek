<?php

Class Register extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('model_login');
    }

    public function index()
    {
        $this->load->view('register_view');
    }

    public function tambah()
    {
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        

        if($this->form_validation->run() == false){
            $this->load->view('register_view');
        }else{
            $this->load->model('model_login');
            $this->model_login->register();
            $this->session->set_flashdata('success_register', 'Proses Pendaftaran User Berhasil');
            redirect('login');
        }
    }
}