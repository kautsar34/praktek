<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_login extends CI_Model {

 public function login_user($username,$password)
 {
  $this->db->where('username', $username);
  $this->db->where('password', $password);
  $query = $this->db->get('tb_user');
  if ($query->num_rows()>0){
   foreach ($query->result() as $row) {
    $sess = array ('username' => $row->username,
        'password' => $row->password
      );
   }
  $this->session->set_userdata($sess);
  redirect('home');
  }
  else{
   $this->session->set_flashdata('info','MAAF Username dan Password Anda salah!, Mohon diperiksa kembali');
   redirect('login');
  }
 }

 public function register()
 {
  $data = [
    "username" => $this->input->post('username', true),
    "password" => $this->input->post('password', true)
];

$this->db->insert('tb_user', $data);
 }

}